# FED-API-TEST

This is a test project i built to show my api integration skills.

I integrated an api to an index.html page using vanilla jsvascript.

Currently the project is here:

- [Go to website](https://fed-api-test.onrender.com/)

## Technologies

This project was built with:

- HTML
- CSS
- Vanilla JAvascript
- External API
- Chart js

Happy viewing.
